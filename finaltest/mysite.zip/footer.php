        <div id="footer_content">
            <p id="footer_logo">PHP 프로그래밍 입문 | <span>한빛 아카데미</span></p>
            <ul id="download">
                <li>예제 소스 다운로드</li>
                <li>- 한빛 아카데미(http://hanbit.co.kr)</li>
                <li>- 코딩스쿨(http://codingschool.info)</li>
            </ul>
            <ul id="author">
                <li>저자 문의 메일</li>
                <li>- 메일 주소 : goldmont@naver.com</li>
            </ul>
        </div>